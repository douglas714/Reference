import { useState } from 'react'
import { Button } from './ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card'
import { Checkbox } from './ui/checkbox'
import { ScrollArea } from './ui/scroll-area'
import logoImage from '../assets/logo.jpeg'

export default function ContractPage({ onAccept }) {
  const [accepted, setAccepted] = useState(false)

  const handleAccept = () => {
    if (accepted) {
      onAccept()
    }
  }

  return (
    <div className="min-h-screen investbet-gradient flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl investbet-card">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <img 
              src={logoImage} 
              alt="InvestBet Capital" 
              className="investbet-logo"
            />
          </div>
          <CardTitle className="text-2xl font-bold text-gray-800">
            Termos de Uso e Contrato
          </CardTitle>
          <CardDescription className="text-gray-600">
            Leia atentamente os termos antes de continuar
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <ScrollArea className="h-64 w-full border rounded-md p-4">
            <div className="space-y-4 text-sm text-gray-700">
              <h3 className="font-semibold text-lg">Termos de Uso - InvestBet Capital</h3>
              
              <p>
                <strong>1. Aceitação dos Termos:</strong> Ao utilizar nossa plataforma de terceirização de trader esportivo, 
                você concorda com todos os termos e condições aqui estabelecidos.
              </p>
              
              <p>
                <strong>2. Serviços Oferecidos:</strong> A InvestBet Capital oferece serviços de análise e execução 
                de operações em apostas esportivas através de traders especializados.
              </p>
              
              <p>
                <strong>3. Riscos:</strong> Todas as operações envolvem riscos financeiros. O usuário está ciente 
                de que pode haver perdas e que os resultados passados não garantem resultados futuros.
              </p>
              
              <p>
                <strong>4. Responsabilidades:</strong> O usuário é responsável por fornecer informações precisas 
                e manter a confidencialidade de suas credenciais de acesso.
              </p>
              
              <p>
                <strong>5. Privacidade:</strong> Respeitamos sua privacidade e protegemos seus dados pessoais 
                conforme nossa política de privacidade.
              </p>
              
              <p>
                <strong>6. Modificações:</strong> Reservamo-nos o direito de modificar estes termos a qualquer momento, 
                com notificação prévia aos usuários.
              </p>
              
              <p>
                <strong>7. Contato:</strong> Para dúvidas ou suporte, entre em contato através dos canais oficiais 
                da InvestBet Capital.
              </p>
            </div>
          </ScrollArea>
          
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="accept-terms" 
              checked={accepted}
              onCheckedChange={setAccepted}
            />
            <label 
              htmlFor="accept-terms" 
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              Li e aceito os termos de uso e contrato
            </label>
          </div>
          
          <Button 
            onClick={handleAccept}
            disabled={!accepted}
            className="w-full"
          >
            Aceitar e Continuar
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}

