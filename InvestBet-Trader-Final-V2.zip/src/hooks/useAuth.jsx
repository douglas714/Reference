import { useState, useEffect, createContext, useContext } from 'react'
import { supabase } from '../lib/supabase'

const AuthContext = createContext({})

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth deve ser usado dentro de um AuthProvider')
  }
  return context
}

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [profile, setProfile] = useState(null)
  const [loading, setLoading] = useState(true)
  const [initialized, setInitialized] = useState(false)

  const fetchProfile = async (userId) => {
    try {
      console.log('useAuth: Buscando perfil para userId:', userId)
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single()

      if (error) {
        console.error('useAuth: Erro ao buscar perfil:', error)
        return null
      }

      console.log('useAuth: Perfil encontrado:', data)
      return data
    } catch (error) {
      console.error('useAuth: Erro inesperado ao buscar perfil:', error)
      return null
    }
  }

  const signIn = async (email, password) => {
    try {
      setLoading(true)
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) {
        console.error('useAuth: Erro no login:', error)
        return { error }
      }

      console.log('useAuth: Login realizado com sucesso:', data)
      return { data }
    } catch (error) {
      console.error('useAuth: Erro inesperado no login:', error)
      return { error }
    } finally {
      setLoading(false)
    }
  }

  const signOut = async () => {
    try {
      setLoading(true)
      const { error } = await supabase.auth.signOut()
      
      if (error) {
        console.error('useAuth: Erro no logout:', error)
        return { error }
      }

      // Limpar estados locais
      setUser(null)
      setProfile(null)
      console.log('useAuth: Logout realizado com sucesso')
      return { success: true }
    } catch (error) {
      console.error('useAuth: Erro inesperado no logout:', error)
      return { error }
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    let mounted = true

    const initializeAuth = async () => {
      try {
        console.log('useAuth: Inicializando autenticação...')
        
        // Obter sessão atual
        const { data: { session }, error } = await supabase.auth.getSession()
        
        if (error) {
          console.error('useAuth: Erro ao obter sessão:', error)
        } else if (session?.user && mounted) {
          console.log('useAuth: Sessão encontrada:', session.user)
          setUser(session.user)
          
          // Buscar perfil
          const profileData = await fetchProfile(session.user.id)
          if (mounted) {
            setProfile(profileData)
          }
        } else {
          console.log('useAuth: Nenhuma sessão encontrada')
        }
      } catch (error) {
        console.error('useAuth: Erro na inicialização:', error)
      } finally {
        if (mounted) {
          setLoading(false)
          setInitialized(true)
        }
      }
    }

    initializeAuth()

    // Listener para mudanças de autenticação
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (!mounted) return

        console.log('useAuth: Mudança de estado de autenticação:', event, session?.user?.id)

        if (event === 'SIGNED_IN' && session?.user) {
          setUser(session.user)
          const profileData = await fetchProfile(session.user.id)
          setProfile(profileData)
        } else if (event === 'SIGNED_OUT') {
          setUser(null)
          setProfile(null)
        }

        setLoading(false)
        setInitialized(true)
      }
    )

    return () => {
      mounted = false
      subscription?.unsubscribe()
    }
  }, [])

  const value = {
    user,
    profile,
    loading,
    initialized,
    signIn,
    signOut,
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}

